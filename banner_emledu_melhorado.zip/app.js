// app.js - EMLEDU interactions
// ------- Configuration -------
const EMLEDU_WHATSAPP = "55SEU_NUMERO_AQUI"; // <- substitua pelo número da EMLEDU (ex: 5591988887777)

// ------- Order form / WhatsApp -------
const orderForm = document.getElementById('orderForm');
const orderResult = document.getElementById('orderResult');

orderForm.addEventListener('submit', e => {
  e.preventDefault();
  const name = document.getElementById('orderName').value.trim();
  const phone = document.getElementById('orderPhone').value.trim();
  const flavor = document.getElementById('orderFlavor').value;
  const qty = document.getElementById('orderQty').value;
  const size = document.getElementById('orderSize').value;
  const date = document.getElementById('orderDate').value;
  const obs = document.getElementById('orderObs').value.trim();

  if(!name || !phone || !flavor || !qty || !size){
    orderResult.textContent = 'Por favor, preencha os campos obrigatórios.';
    return;
  }

  let msg = encodeURIComponent(
    "🍰 NOVA ENCOMENDA EMLEDU\n\n" +
    "Cliente: " + name + "\n" +
    "WhatsApp: " + phone + "\n" +
    "Sabor: " + flavor + "\n" +
    "Quantidade: " + qty + " pote(s)\n" +
    "Tamanho: " + size + "\n" +
    (date ? ('Data desejada: ' + date + "\n") : '') +
    (obs ? ('Observações: ' + obs + "\n") : '') +
    "\n✨ Obrigado pela preferência!"
  );

  const url = 'https://wa.me/' + EMLEDU_WHATSAPP + '?text=' + msg;
  window.open(url, '_blank');

  orderResult.textContent = 'Pedido aberto no WhatsApp.';
  orderForm.reset();
});

// Save draft
document.getElementById('saveDraft').addEventListener('click', () => {
  const draft = {
    name: document.getElementById('orderName').value,
    phone: document.getElementById('orderPhone').value,
    flavor: document.getElementById('orderFlavor').value,
    qty: document.getElementById('orderQty').value,
    size: document.getElementById('orderSize').value,
    date: document.getElementById('orderDate').value,
    obs: document.getElementById('orderObs').value
  };
  localStorage.setItem('emledu_draft', JSON.stringify(draft));
  alert('Rascunho salvo localmente.');
});

// load draft on start
window.addEventListener('load', () => {
  document.getElementById('year').textContent = new Date().getFullYear();
  const draft = localStorage.getItem('emledu_draft');
  if(draft){
    try{
      const d = JSON.parse(draft);
      if(d.name) document.getElementById('orderName').value = d.name;
      if(d.phone) document.getElementById('orderPhone').value = d.phone;
      if(d.flavor) document.getElementById('orderFlavor').value = d.flavor;
      if(d.qty) document.getElementById('orderQty').value = d.qty;
      if(d.size) document.getElementById('orderSize').value = d.size;
      if(d.date) document.getElementById('orderDate').value = d.date;
      if(d.obs) document.getElementById('orderObs').value = d.obs;
    }catch(e){}
  }

  // load reviews
  renderReviews();
});

// ------- Reviews (localStorage) -------
const stars = document.querySelectorAll('.star');
let currentRating = 0;
const selectedRatingEl = document.getElementById('selected-rating');

stars.forEach(s => {
  s.addEventListener('click', () => {
    currentRating = parseInt(s.dataset.value,10);
    paintStars(currentRating);
  });
  s.addEventListener('mouseover', () => paintStars(parseInt(s.dataset.value,10)));
  s.addEventListener('mouseout', () => paintStars(currentRating));
});

function paintStars(r){
  stars.forEach(s => {
    s.classList.toggle('filled', parseInt(s.dataset.value,10) <= r);
    s.setAttribute('aria-checked', parseInt(s.dataset.value,10) === r ? 'true':'false');
  });
  selectedRatingEl.textContent = (r? r.toFixed(1):'0.0') + ' / 5';
}

document.getElementById('submitReview').addEventListener('click', () => {
  const comment = document.getElementById('comment').value.trim();
  if(currentRating < 1){
    alert('Escolha uma nota de 1 a 5 estrelas.');
    return;
  }
  const list = loadReviews();
  list.push({rating: currentRating, comment, date: Date.now()});
  localStorage.setItem('emledu_reviews', JSON.stringify(list));
  document.getElementById('comment').value = '';
  currentRating = 0;
  paintStars(0);
  renderReviews();
});

document.getElementById('clearReviews').addEventListener('click', () => {
  if(confirm('Limpar todas as avaliações salvas localmente?')){
    localStorage.removeItem('emledu_reviews');
    renderReviews();
  }
});

function loadReviews(){
  const raw = localStorage.getItem('emledu_reviews');
  if(!raw) return [];
  try{return JSON.parse(raw);}catch(e){return [];}
}

function renderReviews(){
  const list = loadReviews();
  const reviewsList = document.getElementById('reviewsList');
  const averageEl = document.getElementById('average');
  reviewsList.innerHTML = '';
  if(list.length === 0){
    averageEl.textContent = 'Nenhuma avaliação ainda.';
    reviewsList.innerHTML = '<div class="muted">Seja o primeiro a avaliar!</div>';
    return;
  }
  const avg = list.reduce((a,b)=>a+b.rating,0)/list.length;
  averageEl.textContent = 'Média: ' + avg.toFixed(2) + ' ★ — ' + list.length + ' avaliação(ões).';
  list.slice().reverse().forEach(r => {
    const d = document.createElement('div');
    d.className = 'review';
    d.innerHTML = '<div><strong>' + '★'.repeat(r.rating) + '</strong> <span class="muted"> - ' + new Date(r.date).toLocaleString() + '</span></div><div style="margin-top:6px">' + (r.comment? escapeHtml(r.comment) : '<span class="muted">— sem comentário —</span>') + '</div>';
    reviewsList.appendChild(d);
  });
}

function escapeHtml(unsafe){
  if(!unsafe) return '';
  return unsafe.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}
