Site EMLEDU - Conteúdo:
- index.html
- styles.css
- app.js
- assets/*

Passos para usar:
1) Extraia o ZIP
2) Abra index.html no navegador
3) Substitua EMLEDU_WHATSAPP em app.js pelo número com DDI (ex: 5591988887777)
4) Para publicar, suba os arquivos para GitHub Pages ou um servidor estático.

Se quiser, eu posso publicar para você no GitHub Pages.